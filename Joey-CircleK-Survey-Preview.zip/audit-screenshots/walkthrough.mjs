import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const out = __dirname;
const log = [];
const note = (msg) => {
  console.log(msg);
  log.push(msg);
};

async function shot(page, name) {
  await page.screenshot({ path: path.join(out, `${name}.png`), fullPage: false });
  note(`SHOT ${name}`);
}

async function main() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    // Deny geolocation so getCurrentPosition fails/times out like desktop often does
    permissions: [],
  });
  await context.clearPermissions();
  const page = await context.newPage();

  page.on('requestfailed', (req) => {
    const url = req.url();
    if (url.includes('supabase') || url.includes('stores.json')) {
      note(`FAIL ${url.slice(0, 110)} :: ${req.failure()?.errorText}`);
    }
  });
  page.on('response', (res) => {
    const url = res.url();
    if (url.includes('stores.json')) note(`OK stores.json status=${res.status()}`);
    if (url.includes('supabase')) note(`OK supabase status=${res.status()} ${url.slice(0, 80)}`);
  });

  await page.goto('http://localhost:3000', { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('h1');
  await shot(page, '01-login');

  await page.fill('input[type="email"]', 'mikenierman@gmail.com');
  await page.fill('input[type="password"]', 'demo');
  const loginStart = Date.now();
  await page.click('button[type="submit"]');
  await page.waitForSelector('text=Circle K Route');
  note(`ROUTE_SHELL_MS ${Date.now() - loginStart}`);

  // Time until loading clears / stores appear
  const loadStart = Date.now();
  try {
    await page.waitForFunction(
      () => !document.body.innerText.includes('Loading stores'),
      null,
      { timeout: 90000 }
    );
    note(`LOADING_CLEARED_MS ${Date.now() - loadStart}`);
  } catch {
    note(`LOADING_STUCK_MS ${Date.now() - loadStart}`);
  }

  const storeCount = await page.locator('.store-card').count();
  note(`STORE_CARD_COUNT ${storeCount}`);
  note(`ROUTE_SNIP ${(await page.locator('body').innerText()).slice(0, 450).replace(/\n/g, ' | ')}`);
  await shot(page, '02-route');

  if (storeCount === 0) {
    note('ABORT no stores');
    fs.writeFileSync(path.join(out, 'notes.txt'), log.join('\n'));
    await browser.close();
    return;
  }

  const visitStart = Date.now();
  await page.locator('.store-card').first().click();
  await page.waitForSelector('text=Merch Visit');
  note(`VISIT_OPEN_MS ${Date.now() - visitStart}`);

  const geoWarn = await page.locator('.geo-warn').count();
  note(`GEO_WARN ${geoWarn}`);
  await shot(page, '03-visit-top');

  const skippedChips = await page.locator('.status-chip.skip').count();
  const skippedCards = await page.locator('.phase-card.skipped').count();
  note(`SKIPPED_CHIPS ${skippedChips} SKIPPED_CARDS ${skippedCards}`);
  note(`SKIP_NOTES ${JSON.stringify(await page.locator('.skip-note').allInnerTexts())}`);

  // Mid scroll — stock/fix area
  await page.locator('.phase-card.skipped').first().scrollIntoViewIfNeeded();
  await shot(page, '04-skipped-phases');

  // Full scroll submit area
  await page.locator('.submit-bar').scrollIntoViewIfNeeded();
  note(`SUBMIT_HINT ${await page.locator('.submit-hint').innerText()}`);
  await shot(page, '05-visit-submit');

  // Mid-flow with check-in answers but present still null
  await page.locator('.phase-card').first().scrollIntoViewIfNeeded();
  // Check-in: three questions — pick Could not ask / No patterns via text
  const checkin = page.locator('.phase-card').filter({ hasText: 'Check in' });
  await checkin.getByRole('button', { name: 'Could not ask' }).first().click();
  await checkin.getByRole('button', { name: 'Could not ask' }).nth(1).click().catch(async () => {
    await checkin.getByRole('button', { name: 'No' }).first().click();
  });
  // selling — No
  const sellingNo = checkin.getByRole('button', { name: 'No' });
  if (await sellingNo.count()) await sellingNo.first().click();
  // pouches
  const pouchNo = checkin.getByRole('button', { name: 'No' });
  if (await pouchNo.count()) await pouchNo.last().click();

  note(`SKIPPED_STILL_BEFORE_PRESENT ${await page.locator('.phase-card.skipped').count()}`);
  await page.locator('.phase-card.skipped').first().scrollIntoViewIfNeeded();
  await shot(page, '06-still-skipped-unanswered-present');

  // Answer Find: reset Yes, present Yes
  const find = page.locator('.phase-card').filter({ hasText: 'Find it' });
  await find.scrollIntoViewIfNeeded();
  const findYes = find.getByRole('button', { name: 'Yes' });
  await findYes.nth(0).click();
  await findYes.nth(1).click();
  await page.waitForTimeout(250);
  note(`SKIPPED_AFTER_PRESENT_YES ${await page.locator('.phase-card.skipped').count()}`);
  note(`STOCK_CHIP ${(await page.locator('.phase-card').filter({ hasText: 'Check and fill' }).locator('.status-chip').innerText().catch(() => 'n/a'))}`);
  await page.locator('.phase-card').filter({ hasText: 'Check and fill' }).scrollIntoViewIfNeeded();
  await shot(page, '07-stock-unlocked');

  // Back + admin
  await page.locator('.back-btn').click();
  await page.waitForSelector('text=Circle K Route');
  await page.getByRole('button', { name: 'Sign out' }).click();
  await page.waitForSelector('input[type="email"]');

  await page.fill('input[type="email"]', 'mike@direct2retailers.com');
  await page.fill('input[type="password"]', 'demo');
  const adminStart = Date.now();
  await page.click('button[type="submit"]');
  await page.waitForSelector('.admin-view, .route-view', { timeout: 90000 });
  if (await page.locator('.admin-view').count()) {
    note(`ADMIN_DIRECT_MS ${Date.now() - adminStart}`);
  } else {
    await page.getByRole('button', { name: 'Dashboard' }).click();
    await page.waitForSelector('.admin-view');
    note(`ADMIN_VIA_ROUTE_MS ${Date.now() - adminStart}`);
  }
  await page.waitForTimeout(500);
  note(`ADMIN_SNIP ${(await page.locator('body').innerText()).slice(0, 500).replace(/\n/g, ' | ')}`);
  await shot(page, '08-admin');

  // GPS timeout path (fresh context with granted but hanging geolocation)
  const ctx2 = await browser.newContext({
    viewport: { width: 390, height: 844 },
  });
  await ctx2.grantPermissions(['geolocation']);
  // No setGeolocation → Chromium may hang until timeout
  const p2 = await ctx2.newPage();
  await p2.goto('http://localhost:3000');
  await p2.fill('input[type="email"]', 'mikenierman@gmail.com');
  await p2.fill('input[type="password"]', 'demo');
  await p2.click('button[type="submit"]');
  await p2.waitForFunction(() => !document.body.innerText.includes('Loading stores'), null, {
    timeout: 90000,
  });
  const gpsStart = Date.now();
  await p2.locator('.store-card').first().click();
  await p2.waitForSelector('text=Merch Visit');
  note(`GPS_VISIT_OPEN_MS ${Date.now() - gpsStart}`);
  await p2.screenshot({ path: path.join(out, '09-gps-path-visit.png') });
  await ctx2.close();

  fs.writeFileSync(path.join(out, 'notes.txt'), log.join('\n'));
  await browser.close();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
